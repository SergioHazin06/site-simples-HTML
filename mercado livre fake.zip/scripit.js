const products = [
    { name: "Produto 1", price: "R$ 100,00", image: "https://via.placeholder.com/200" },
    { name: "Produto 2", price: "R$ 200,00", image: "https://via.placeholder.com/200" },
    { name: "Produto 3", price: "R$ 300,00", image: "https://via.placeholder.com/200" },
    { name: "Produto 4", price: "R$ 400,00", image: "https://via.placeholder.com/200" }
];

function searchProducts() {
    const searchInput = document.getElementById('search-input').value.toLowerCase();
    const productGrid = document.getElementById('product-grid');
    productGrid.innerHTML = '';

    const filteredProducts = products.filter(product =>
        product.name.toLowerCase().includes(searchInput)
    );

    filteredProducts.forEach(product => {
        const productDiv = document.createElement('div');
        productDiv.classList.add('product');

        productDiv.innerHTML = `
            <img src="${product.image}" alt="${product.name}">
            <h3>${product.name}</h3>
            <p>${product.price}</p>
        `;

        productGrid.appendChild(productDiv);
    });

    if (filteredProducts.length === 0) {
        productGrid.innerHTML = '<p>Nenhum produto encontrado</p>';
    }
}
